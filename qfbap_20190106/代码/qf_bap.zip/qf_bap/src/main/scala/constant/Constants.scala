package constant

/**
  * 常量
  */
object Constants {

  val SPARK_APP_NAME_USER = "UserProcessing"
  val SPARK_LOCAL = "spark.local"















}
